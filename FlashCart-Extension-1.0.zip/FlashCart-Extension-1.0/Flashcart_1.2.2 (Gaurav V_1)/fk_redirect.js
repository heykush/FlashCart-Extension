console.log("I am from fk_redirect.js");
window.location.href='https://www.flipkart.com/checkout/init?loginFlow=false&type=flash';